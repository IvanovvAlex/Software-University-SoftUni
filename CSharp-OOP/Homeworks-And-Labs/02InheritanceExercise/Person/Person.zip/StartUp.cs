﻿using System;

namespace Person
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string name = Console.ReadLine();
            int age = int.Parse(Console.ReadLine());

            Child child = new Child(name, age);
            //if (child.Age <= 0 || child.Age > 15)
            //{
            //    return;
            //}
            Console.WriteLine(child);
        }
    }
}